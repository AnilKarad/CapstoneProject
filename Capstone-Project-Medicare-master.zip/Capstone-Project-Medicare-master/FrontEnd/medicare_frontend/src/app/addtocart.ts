export class Addtocart {
    constructor(public cartid:number,public email:string,public name:string,public medid:number,public medname:string,public price:number){}
}
