export class Medicine {
    medid : number = 0;
        medname : string = '';
        price : number = 0;
        seller : string = '';
        description : string = '';
        category : string = '';
        medimg : string = '';
}
export interface medicine {
    medid : number;
    medname : string;
    price : number;
    seller : string;
    description : string;
    medimg : string;
    category : string;
}
